export default {
  signin_background: require('../../assets/images/login_backgroud.png'),
  signup_background: require('../../assets/images/signup_backgroud.jpg'),
  cat_logo: require('../../assets/images/cat_logo.png'),
  logo: require('../../assets/images/Logo.png'),
  logo_white: require('../../assets/images/Logo_white.png'),

  startpage_image1: require('../../assets/images/a1.png'),
  startpage_image2: require('../../assets/images/a2.png'),
  startpage_image3: require('../../assets/images/a3.png'),
  startpage_image4: require('../../assets/images/a4.png'),
  startpage_image5: require('../../assets/images/a5.png'),

  user_image: require('../../assets/images/Boyle.jpg'),
  talk_image: require('../../assets/images/2.png'),

  play_icon: require('../../assets/icons/play.png')

};

  
