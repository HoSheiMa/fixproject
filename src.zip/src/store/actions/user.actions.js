export const LOGIN = 'user_login';
export const COURSE_SEL ='course_select'
export const VIDEO_SEL = 'video_select'
export const LOGOUT = 'user_logout';